# Write your MySQL query statement below
Select product_id from Products where low_fats = 'Y' and recyclable = 'Y'
