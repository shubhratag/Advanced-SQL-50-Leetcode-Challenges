# Write your MySQL query statement below
Select name from Customer where referee_id is null or referee_id != 2
